def wrapper_fun (arg):
    return base_fun(arg)*2
def base_fun(arg):
    return arg*2