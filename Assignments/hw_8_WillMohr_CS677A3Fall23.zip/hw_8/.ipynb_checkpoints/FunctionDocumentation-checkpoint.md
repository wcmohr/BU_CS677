def poly_expansion(X,D):
    """Args: X --> marix of data (observations are rows, values are columns) 
             D --> max polynomial value 
       Return: polynomial expanded observations, where first D columns are
               the polynomial expansions of the first value of each observation,
               the second D columns are the seconds value, etc.
    """